create table practice
(
    id bigint auto_increment
        primary key
)
    charset = latin1;

INSERT INTO s09p12a410.practice (id) VALUES (1);
