create table comment
(
    comment_id bigint auto_increment
        primary key,
    created_at datetime(6)  null,
    member_id  bigint       null,
    star_id    bigint       null,
    updated_at datetime(6)  null,
    content    varchar(255) not null,
    constraint FKm7fk27bkb4e9du51it2skuxhb
        foreign key (star_id) references star (star_id),
    constraint FKmrrrpi513ssu63i2783jyiv9m
        foreign key (member_id) references member (member_id)
);

INSERT INTO s09p12a410.comment (comment_id, created_at, member_id, star_id, updated_at, content) VALUES (1, '2023-08-17 15:32:57.420484', 7, 1, '2023-08-17 15:32:57.420484', '황금올리브도 맛있지만 자메이카 통다리 구이가 더 맛있는듯??');
INSERT INTO s09p12a410.comment (comment_id, created_at, member_id, star_id, updated_at, content) VALUES (2, '2023-08-17 15:36:54.363320', 2, 2, '2023-08-17 15:36:54.363320', '자메이카 통다리 맛잇죠 ㅎㅎ');
INSERT INTO s09p12a410.comment (comment_id, created_at, member_id, star_id, updated_at, content) VALUES (3, '2023-08-17 15:39:08.244250', 3, 2, '2023-08-17 15:39:08.244250', '허니콤보 한입 하실래여?');
INSERT INTO s09p12a410.comment (comment_id, created_at, member_id, star_id, updated_at, content) VALUES (4, '2023-08-17 15:42:08.751015', 12, 3, '2023-08-17 15:42:08.751015', '건강해보이네;;');
INSERT INTO s09p12a410.comment (comment_id, created_at, member_id, star_id, updated_at, content) VALUES (5, '2023-08-17 15:45:56.419879', 16, 7, '2023-08-17 15:45:56.419879', '비엘티 저렇게 먹어봤는데 괜찮은듯!');
INSERT INTO s09p12a410.comment (comment_id, created_at, member_id, star_id, updated_at, content) VALUES (6, '2023-08-17 15:48:54.623032', 16, 8, '2023-08-17 15:48:54.623032', '슉 슈슉 슉 슉 슈슉');
INSERT INTO s09p12a410.comment (comment_id, created_at, member_id, star_id, updated_at, content) VALUES (7, '2023-08-17 15:57:25.188932', 5, 7, '2023-08-17 15:57:25.188932', '좋은 정보 감사합니당 ^0^');
INSERT INTO s09p12a410.comment (comment_id, created_at, member_id, star_id, updated_at, content) VALUES (8, '2023-08-17 16:02:54.471593', 15, 6, '2023-08-17 16:02:54.471593', '지코바? 체인인가요?');
INSERT INTO s09p12a410.comment (comment_id, created_at, member_id, star_id, updated_at, content) VALUES (9, '2023-08-17 16:07:55.628055', 7, 18, '2023-08-17 16:07:55.628055', '버섯에 글자가 적혀있네요!');
INSERT INTO s09p12a410.comment (comment_id, created_at, member_id, star_id, updated_at, content) VALUES (10, '2023-08-17 16:14:36.943764', 22, 20, '2023-08-17 16:14:36.943764', '오 나도 언젠가 해보고싶다');
INSERT INTO s09p12a410.comment (comment_id, created_at, member_id, star_id, updated_at, content) VALUES (11, '2023-08-17 16:40:07.729517', 22, 26, '2023-08-17 16:40:07.729517', '오 굿굿!!');
INSERT INTO s09p12a410.comment (comment_id, created_at, member_id, star_id, updated_at, content) VALUES (12, '2023-08-17 16:51:01.685566', 20, 33, '2023-08-17 16:51:01.685566', '오오 저도 지금 치킨 먹으려고 하는데 맛있게 드세용ㅎㅎ');
INSERT INTO s09p12a410.comment (comment_id, created_at, member_id, star_id, updated_at, content) VALUES (13, '2023-08-17 16:56:50.173657', 20, 1, '2023-08-17 16:56:50.173657', '왜 이렇게 맛있어보여요!!');
