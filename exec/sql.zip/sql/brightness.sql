create table brightness
(
    member_id bigint not null,
    star_id   bigint not null,
    primary key (member_id, star_id),
    constraint FK68vqtkcts5t6k329ulgy7ue99
        foreign key (member_id) references member (member_id),
    constraint FKf43emtjw0xi9qsph9k53ycnuc
        foreign key (star_id) references star (star_id)
);

INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (1, 33);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (2, 2);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (2, 33);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (3, 2);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (4, 33);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (5, 7);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (6, 33);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (7, 1);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (10, 33);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (12, 3);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (12, 4);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (14, 33);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (15, 6);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (15, 33);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (16, 7);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (16, 8);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (18, 33);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (20, 1);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (20, 33);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (22, 20);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (22, 33);
INSERT INTO s09p12a410.brightness (member_id, star_id) VALUES (24, 33);
