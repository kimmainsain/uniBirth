create table planet
(
    created_at datetime(6)                  null,
    planet_id  bigint auto_increment
        primary key,
    updated_at datetime(6)                  null,
    title      varchar(255) default 'title' null
);

INSERT INTO s09p12a410.planet (created_at, planet_id, updated_at, title) VALUES ('2023-08-07 16:05:38.000000', 1, '2023-08-07 16:05:38.000000', 'Planet1');
INSERT INTO s09p12a410.planet (created_at, planet_id, updated_at, title) VALUES ('2023-08-07 16:05:38.000000', 2, '2023-08-07 16:05:38.000000', 'Planet2');
INSERT INTO s09p12a410.planet (created_at, planet_id, updated_at, title) VALUES ('2023-08-07 16:05:38.000000', 3, '2023-08-07 16:05:38.000000', 'Planet3');
INSERT INTO s09p12a410.planet (created_at, planet_id, updated_at, title) VALUES ('2023-08-07 16:05:38.000000', 4, '2023-08-07 16:05:38.000000', 'Planet4');
INSERT INTO s09p12a410.planet (created_at, planet_id, updated_at, title) VALUES ('2023-08-07 16:05:38.000000', 5, '2023-08-07 16:05:38.000000', 'Planet5');
INSERT INTO s09p12a410.planet (created_at, planet_id, updated_at, title) VALUES ('2023-08-07 16:05:38.000000', 6, '2023-08-07 16:05:38.000000', 'Planet6');
INSERT INTO s09p12a410.planet (created_at, planet_id, updated_at, title) VALUES ('2023-08-07 16:05:38.000000', 7, '2023-08-07 16:05:38.000000', 'Planet7');
INSERT INTO s09p12a410.planet (created_at, planet_id, updated_at, title) VALUES ('2023-08-07 16:05:38.000000', 8, '2023-08-07 16:05:38.000000', 'Planet8');
