create table pin
(
    constellation_id bigint not null,
    member_id        bigint not null,
    primary key (constellation_id, member_id),
    constraint FK8po36c66d4aq04lrmnc4immmf
        foreign key (member_id) references member (member_id),
    constraint FKk54sd5obacpqxt20kj73vwuoi
        foreign key (constellation_id) references constellation (constellation_id)
);

INSERT INTO s09p12a410.pin (constellation_id, member_id) VALUES (17, 1);
INSERT INTO s09p12a410.pin (constellation_id, member_id) VALUES (17, 22);
