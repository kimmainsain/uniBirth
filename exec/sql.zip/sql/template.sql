create table template
(
    board_size  int          default 10    not null,
    point_count int          default 0     not null,
    created_at  datetime(6)                null,
    template_id bigint auto_increment
        primary key,
    updated_at  datetime(6)                null,
    image_url   varchar(255)               not null,
    line_list   varchar(255) default '[]'  null,
    point_list  varchar(255) default '[]'  null,
    title       varchar(255) default '행성명' null
);

INSERT INTO s09p12a410.template (board_size, point_count, created_at, template_id, updated_at, image_url, line_list, point_list, title) VALUES (5, 10, '2023-08-14 12:50:49.000000', 1, '2023-08-14 12:50:52.000000', 'https://firebasestorage.googleapis.com/v0/b/uni-birth.appspot.com/o/images%2Fconstellation-1691986048152.png?alt=media&token=77a460e4-c1b4-47cd-936e-5b5af71925da', '[[2, 1, 0, 1], [0, 1, 1, 2], [1, 2, 0, 3], [0, 3, 2, 3], [2, 1, 2, 3], [2, 1, 4, 1], [2, 3, 4, 3], [2, 1, 4, 0], [4, 0, 4, 4], [2, 3, 4, 4]]', '[[0, 1], [0, 3], [1, 2], [2, 1], [2, 3], [4, 0], [4, 1], [4, 3], [4, 4]]', '고양이');
INSERT INTO s09p12a410.template (board_size, point_count, created_at, template_id, updated_at, image_url, line_list, point_list, title) VALUES (5, 11, '2023-08-14 13:03:59.000000', 2, '2023-08-14 13:04:00.000000', 'https://firebasestorage.googleapis.com/v0/b/uni-birth.appspot.com/o/images%2Fconstellation-1691985432459.png?alt=media&token=e81319ee-c4ca-4522-8a61-8b32802ab57b', '[[0,1,2,1],[0,1,2,2],[2,2,0,3],[0,3,2,3],[2,1,3,1],[3,1,4,2],[4,2,3,3],[3,3,2,3],[3,3,2,4],[3,3,3,4],[3,1,2,0],[3,1,3,0]]', '[[0, 1], [0, 3], [2, 0], [2, 1], [2, 2], [2, 3], [2, 4], [3, 0], [3, 1], [3, 3], [3, 4], [4, 2]]', '여우');
INSERT INTO s09p12a410.template (board_size, point_count, created_at, template_id, updated_at, image_url, line_list, point_list, title) VALUES (5, 8, '2023-08-14 13:20:52.000000', 3, '2023-08-14 13:20:23.000000', 'https://firebasestorage.googleapis.com/v0/b/uni-birth.appspot.com/o/images%2Fconstellation-1691986738219.png?alt=media&token=ce66a216-5563-487a-a27e-613b0a1ad2b5', '[[2, 0, 0, 2], [2, 0, 4, 2], [0, 2, 2, 3], [2, 3, 1, 4], [1, 4, 3, 4], [3, 4, 2, 3], [2, 3, 4, 2], [0, 2, 4, 2], [1, 1, 3, 1]]', '[[0, 2], [1, 1], [1, 4], [2, 0], [2, 1], [2, 3], [3, 1], [3, 4], [4, 2]]', '물고기');
INSERT INTO s09p12a410.template (board_size, point_count, created_at, template_id, updated_at, image_url, line_list, point_list, title) VALUES (5, 9, '2023-08-14 13:29:47.000000', 4, '2023-08-14 13:29:22.000000', 'https://firebasestorage.googleapis.com/v0/b/uni-birth.appspot.com/o/images%2Fconstellation-1691987277397.png?alt=media&token=c652a4d8-cfc6-45c9-945d-e60517c3b64b', '[[2, 2, 0, 1], [0, 1, 2, 1], [2, 1, 2, 3], [2, 3, 0, 3], [0, 3, 1, 1], [2, 2, 4, 2], [4, 2, 3, 0], [4, 2, 3, 4], [2, 2, 0, 3], [0, 1, 1, 3]]', '[[0, 1], [0, 3], [1, 1], [1, 3], [2, 1], [2, 2], [2, 3], [3, 0], [3, 4], [4, 2]]', '튤립');
