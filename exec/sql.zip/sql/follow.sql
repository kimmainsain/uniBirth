create table follow
(
    follow_from bigint not null,
    follow_to   bigint not null,
    primary key (follow_from, follow_to),
    constraint FKcm1dbw5mk6d77i981hf44jllp
        foreign key (follow_from) references member (member_id),
    constraint FKsmpc5eydqy0y82tajex3dcthc
        foreign key (follow_to) references member (member_id)
);

INSERT INTO s09p12a410.follow (follow_from, follow_to) VALUES (1, 12);
INSERT INTO s09p12a410.follow (follow_from, follow_to) VALUES (1, 20);
INSERT INTO s09p12a410.follow (follow_from, follow_to) VALUES (3, 2);
INSERT INTO s09p12a410.follow (follow_from, follow_to) VALUES (5, 16);
INSERT INTO s09p12a410.follow (follow_from, follow_to) VALUES (6, 5);
INSERT INTO s09p12a410.follow (follow_from, follow_to) VALUES (12, 2);
INSERT INTO s09p12a410.follow (follow_from, follow_to) VALUES (16, 14);
INSERT INTO s09p12a410.follow (follow_from, follow_to) VALUES (18, 5);
INSERT INTO s09p12a410.follow (follow_from, follow_to) VALUES (20, 1);
INSERT INTO s09p12a410.follow (follow_from, follow_to) VALUES (22, 17);
INSERT INTO s09p12a410.follow (follow_from, follow_to) VALUES (22, 20);
INSERT INTO s09p12a410.follow (follow_from, follow_to) VALUES (24, 22);
